<template>
  <div class="animsition dashboard">
            <transition>
                <keep-alive>
                    <router-view></router-view>
                </keep-alive>
            </transition>
  </div>
</template>
<script>
export default {
  
}
</script>
